
---

## DeepSeek Integration (Free Chat)

DeepSeek (chat.deepseek.com) is also supported as a second provider.

### Important: DeepSeek Session Setup

DeepSeek uses AWS WAF with a visual captcha that **can't be solved headless**.
Unlike Qwen (which auto-logs in), DeepSeek requires a one-time manual session export:

1. **Log into chat.deepseek.com** in your normal browser (Chrome/Firefox)
2. Open **DevTools** (F12) → **Application** tab
3. Copy **Cookies** for `.deepseek.com` (need: `aws-waf-token`, `smidV2`)
4. Copy **Local Storage** for `chat.deepseek.com` (need: `userToken`, `settingsJwt`, `__appKit_userInfo`)
5. Create `mini-services/deepseek-proxy/session.json` in this format:
   ```json
   {
     "cookies": [
       {"name": "aws-waf-token", "value": "...", "domain": ".deepseek.com", "path": "/"}
     ],
     "localStorage": {
       "userToken": "{\"value\":\"...\"}",
       "settingsJwt": "{\"value\":{...}}"
     }
   }
   ```
6. Start the DeepSeek proxy: `cd mini-services/deepseek-proxy && ./manage.sh start`

### Using DeepSeek

The proxy runs on port **3032**. Use these models:

| Model | Description |
|-------|-------------|
| `deepseek-chat` | Instant mode — fast responses (V3) |
| `deepseek-reasoner` | Deep thinking mode (R1) |

```bash
curl -N http://localhost:3000/api/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"Hi"}],"stream":true}'
```

### Session Expiry

If the DeepSeek proxy shows "session expired", just re-export your cookies
from the browser and update `session.json`. The proxy will pick it up on restart.

### Two Proxies Running

You need **both** proxies running for full functionality:

```bash
# Terminal 1: Qwen proxy (port 3030)
cd mini-services/qwen-proxy && ./manage.sh start

# Terminal 2: DeepSeek proxy (port 3032)
cd mini-services/deepseek-proxy && ./manage.sh start

# Terminal 3: Dashboard (port 3000)
npm run dev
```

The Next.js API route automatically routes based on model name:
- `qwen*` → port 3030 (Qwen proxy)
- `deepseek*` → port 3032 (DeepSeek proxy)
