# Qwen Chat API — Local Setup Guide

An OpenAI-compatible API proxy for **chat.qwen.ai** with a full dashboard.

## What This Does

- Turns your Qwen account into an OpenAI-compatible API (`/v1/chat/completions`)
- Works with Cline, LangChain, Open WebUI, Cursor, and any OpenAI SDK
- Real streaming (SSE) from Qwen's actual API response
- Chat continuity (multi-turn conversations, not isolated messages)
- Thinking mode toggle (Auto / Thinking / Fast)
- Persistent analytics + logs (saved to `logs.json`)
- Dashboard with Chats list, Playground, Logs, Analytics, Settings tabs

## How It Works

```
Cline / curl / any OpenAI client
        │
        ▼
┌───────────────────┐     ┌──────────────────────┐
│  Next.js Dashboard │────►│  Qwen Proxy (Bun)    │
│  localhost:3000    │     │  localhost:3030       │
└───────────────────┘     │                       │
                          │  ┌─────────────────┐  │
                          │  │ Headless Chromium │──┼──► chat.qwen.ai
                          │  │ (invisible)      │  │    (Baxia ✓)
                          │  └─────────────────┘  │
                          └──────────────────────┘
```

The proxy drives a **headless browser** (invisible Chromium) that logs into
chat.qwen.ai and intercepts the API response streams. This is required because
Qwen uses Baxia anti-bot protection — you can't call the API directly without
a real browser session.

---

## Prerequisites

### 1. Install Node.js (v18+)
```bash
# Download from https://nodejs.org/ or use nvm:
nvm install 18
nvm use 18
```

### 2. Install Bun (for the proxy service)
```bash
# macOS/Linux:
curl -fsSL https://bun.sh/install | bash

# Windows (PowerShell):
powershell -c "irm bun.sh/install.ps1 | iex"
```

### 3. A Qwen Account
- Sign up at https://chat.qwen.ai (free)
- You need the email + password (NOT Google OAuth — use email/password)

---

## Setup (5 minutes)

### Step 1: Extract the zip
```bash
unzip qwen-chat-api-local.zip
cd qwen-chat-api-local
```

### Step 2: Install the dashboard dependencies
```bash
# In the project root (where package.json is)
npm install
# or: bun install
```

### Step 3: Configure the proxy credentials
```bash
cd mini-services/qwen-proxy
```

Edit `.env` and add your Qwen credentials:
```env
QWEN_EMAIL=your-email@gmail.com
QWEN_PASSWORD=your-password-here
```

### Step 4: Install the proxy dependencies
```bash
# Still in mini-services/qwen-proxy/
bun install
```

### Step 5: Install Playwright's Chromium browser
```bash
bunx playwright install chromium
```

This downloads ~180MB of Chromium. Only needed once.

---

## Running It

You need **two terminals** running:

### Terminal 1: Start the proxy
```bash
cd mini-services/qwen-proxy
./manage.sh start
```

You should see:
```
starting qwen-proxy…
ready (pid XXXX)
```

The proxy is now running on `localhost:3030`. It will:
- Launch a headless Chromium browser
- Log into chat.qwen.ai with your credentials
- Inject a fetch interceptor to capture SSE streams
- Expose the OpenAI-compatible API

### Terminal 2: Start the dashboard
```bash
# In the project root
npm run dev
# or: bun run dev
```

You should see:
```
▲ Next.js 16.x
- Local: http://localhost:3000
```

### Step 3: Open the dashboard
Open http://localhost:3000 in your browser. You should see:
- **"Online"** badge in the top right
- Setup tab with your API key and Cline instructions
- Playground tab for testing
- Chats tab showing your Qwen chat history

---

## Using with Cline (VS Code)

1. Open Cline settings in VS Code
2. **API Provider**: `OpenAI Compatible`
3. **Base URL**: `http://localhost:3000/api/v1`
4. **API Key**: (any string, e.g. `sk-qwen-local`)
5. **Model**: `qwen3.7-plus` (or `qwen3.8-max`)

That's it! Cline will now use Qwen as if it were the OpenAI API.

### Test with curl
```bash
# Streaming
curl -N http://localhost:3000/api/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.7-plus",
    "messages": [{"role": "user", "content": "Hello!"}],
    "stream": true
  }'

# Non-streaming
curl -X POST http://localhost:3000/api/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.7-plus",
    "messages": [{"role": "user", "content": "Say hi"}],
    "stream": false
  }'

# List models
curl http://localhost:3000/api/v1/models
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/chat/completions` | OpenAI-compatible chat (streaming + non-streaming) |
| GET | `/api/v1/models` | List available Qwen models (6 models) |
| GET | `/api/v1/chats` | List your Qwen chat history |
| POST | `/api/v1/chats/select` | Switch active chat |
| POST | `/api/v1/chats/new` | Start a new chat |
| GET | `/api/v1/state` | Get current mode + active chat |
| POST | `/api/v1/state` | Update mode toggles |
| GET | `/api/v1/logs` | Request history (persisted) |
| GET | `/api/v1/analytics` | Token usage stats |
| GET | `/api/v1/health` | Proxy health check |

### Chat request body (OpenAI-compatible)
```json
{
  "model": "qwen3.7-plus",
  "messages": [
    {"role": "user", "content": "Hello"}
  ],
  "stream": true,
  "thinking": false,
  "search": true
}
```

- `thinking`: `false` = Fast mode, `true` = Thinking mode
- `search`: `true` = Auto mode (Qwen decides whether to search)

---

## Thinking Modes

The dashboard Playground has three mode buttons (like the Qwen app):

| Mode | Description | When to use |
|------|-------------|-------------|
| **Auto** | Qwen decides automatically | General use (default) |
| **Thinking** | Deep reasoning before answering | Complex problems, math, coding |
| **Fast** | No thinking, quick response | Simple questions, greetings |

For API/Cline, pass the mode in the request body:
- Fast: `"thinking": false`
- Thinking: `"thinking": true`
- Auto: `"thinking": true, "search": true`

---

## Proxy Management

The proxy runs as a background daemon. Use `manage.sh` to control it:

```bash
cd mini-services/qwen-proxy

./manage.sh start     # Start the proxy
./manage.sh stop      # Stop the proxy
./manage.sh restart   # Restart the proxy
./manage.sh status    # Check if running + health info
```

### Files created by the proxy
- `.browser-data/` — Chromium profile (cookies, session) — keeps you logged in
- `logs.json` — Persistent request history (survives restarts)
- `proxy.log` — Debug log
- `proxy.pid` — Process ID file

---

## Troubleshooting

### "Proxy offline" in the dashboard
1. Check the proxy is running: `./manage.sh status`
2. If not, start it: `./manage.sh start`
3. Check `proxy.log` for errors: `tail -50 proxy.log`

### Login fails
- Verify your email/password in `.env`
- Qwen may show a captcha — try logging in manually once at chat.qwen.ai first
- The proxy saves the browser session in `.browser-data/`, so you only log in once

### Streaming is slow / cuts off
- Make sure you're using the latest proxy (the SSE interception fix)
- Check `proxy.log` for `[stream] done after Xms` — should show the actual stream time
- Long responses (1000+ words) take 30-90 seconds — that's Qwen's generation time

### "Executable doesn't exist" error
Run `bunx playwright install chromium` to install the browser.

### Port already in use
```bash
./manage.sh stop
./manage.sh start
```

---

## Python Alternative (Optional)

If you prefer Python over Bun, there's a standalone Python proxy:

```bash
cd mini-services/qwen-python
pip install -r requirements.txt
playwright install chromium
python qwen_proxy.py
```

Runs on `localhost:3031` (different port). Same features, same API.
Use this if you don't want to install Bun/Node.

---

## Architecture Notes

### Why a browser is required
Qwen uses **Baxia anti-bot** (Alibaba's security SDK). Every API request must
carry a cryptographic `bx-*` token generated inside a real browser via
`window.__baxia__.getFYModule.getUidToken()`. Direct `fetch()`/`curl` calls
hang silently because Baxia blocks them.

The proxy:
1. Drives the Qwen UI (type + click Send) — Qwen's app makes the API call
2. **Intercepts the response stream** (via fetch.body.tee())
3. Forwards the real SSE chunks to API clients

This gives us real streaming, proper `[DONE]` detection, and complete responses.

### Why the dashboard shows "offline" on Cloudflare Pages
The live dashboard at https://qwen-chat-api.pages.dev is static hosting — it
can't run a browser. You must run the proxy locally (or on a VPS) and enter
its URL in the Setup tab's "Proxy URL" field.

---

## Quick Start (TL;DR)

```bash
# 1. Extract
unzip qwen-chat-api-local.zip
cd qwen-chat-api-local

# 2. Install dashboard deps
npm install

# 3. Configure proxy
cd mini-services/qwen-proxy
echo "QWEN_EMAIL=you@email.com" > .env
echo "QWEN_PASSWORD=yourpass" >> .env
bun install
bunx playwright install chromium

# 4. Start proxy
./manage.sh start

# 5. Start dashboard (new terminal)
cd ../..
npm run dev

# 6. Open http://localhost:3000
# 7. In Cline: Base URL = http://localhost:3000/api/v1
```

---

## File Structure

```
qwen-chat-api-local/
├── package.json              # Next.js dashboard
├── next.config.ts
├── tsconfig.json
├── tailwind.config.ts
├── postcss.config.mjs
├── components.json
├── eslint.config.mjs
├── src/
│   ├── app/
│   │   ├── page.tsx          # Dashboard (6 tabs)
│   │   ├── layout.tsx
│   │   ├── globals.css
│   │   └── api/
│   │       ├── route.ts
│   │       └── v1/[...path]/route.ts   # Proxy relay
│   └── components/ui/        # shadcn/ui components (48 files)
├── public/
│   ├── logo.svg
│   └── robots.txt
├── mini-services/
│   ├── qwen-proxy/           # Main proxy (Bun + Playwright)
│   │   ├── index.ts          # Proxy server
│   │   ├── manage.sh         # Start/stop script
│   │   ├── package.json
│   │   └── .env              # Your credentials (EDIT THIS)
│   └── qwen-python/          # Python alternative (optional)
│       ├── qwen_proxy.py
│       ├── requirements.txt
│       └── README.md
└── README.md                 # This file
```

---

## Security Notes

- **Never commit `.env`** — it contains your Qwen password
- The `.gitignore` already excludes `.env`, `.browser-data/`, `logs.json`
- The proxy doesn't enforce API key auth (any string works) — don't expose
  port 3030 to the public internet without adding auth
- Logs in `logs.json` contain prompt/response text — be mindful of sensitive data

---

## Support

- GitHub repo: https://github.com/ggcoding771/qwen-chat-api
- Issues: https://github.com/ggcoding771/qwen-chat-api/issues

---

**Made for the open-source community.**
