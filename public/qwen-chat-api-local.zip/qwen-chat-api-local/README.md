# Qwen + DeepSeek Chat API
## Quick Start
```bash
bash install.sh
python3 run.py
```
Open http://localhost:8000
## Cline
- Base URL: http://localhost:8000/v1
- API Key: sk-local
- Model: qwen3.7-plus or deepseek-chat
