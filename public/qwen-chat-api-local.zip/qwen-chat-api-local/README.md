# Qwen + DeepSeek Chat API — Local Setup Guide

An OpenAI-compatible API proxy for **chat.qwen.ai** and **chat.deepseek.com** — both free chat services.

## What This Does

- Turns your Qwen + DeepSeek accounts into an OpenAI-compatible API
- Works with Cline, LangChain, Open WebUI, Cursor, and any OpenAI SDK
- **Real streaming** (SSE) from actual API responses (not DOM scraping)
- **Stop support** — pressing Stop in Cline immediately stops generation
- Chat continuity (multi-turn conversations)
- Thinking mode toggle (Auto / Thinking / Fast)
- Dual-provider dashboard with live status badges
- Persistent analytics + logs

## Quick Start (TL;DR)

```bash
# 1. Extract
unzip qwen-chat-api-local.zip
cd qwen-chat-api-local

# 2. Install dashboard deps
npm install

# 3. Run interactive setup (opens browser for login)
python setup.py

# 4. Or manual setup:
cd mini-services/qwen-proxy
echo "QWEN_EMAIL=you@email.com" > .env
echo "QWEN_PASSWORD=yourpass" >> .env
bun install
bunx playwright install chromium
./manage.sh start

# 5. Start dashboard (new terminal)
cd ../..
npm run dev

# 6. Open http://localhost:3000
# 7. In Cline: Base URL = http://localhost:3000/api/v1
```

---

## Prerequisites

1. **Node.js** v18+ → https://nodejs.org
2. **Bun** → `curl -fsSL https://bun.sh/install | bash`
3. **Python 3.8+** (for interactive setup) → https://python.org
4. **Qwen account** → https://chat.qwen.ai (email/password, not OAuth)
5. **DeepSeek account** → https://chat.deepseek.com (same or different email)

---

## Setup Options

### Option 1: Interactive Setup (Recommended)

```bash
python setup.py
```

This gives you two choices for each provider:

**A) Browser Login** — opens a real Chromium window, you log in normally, it captures your session automatically.

**B) Console Snippet** — paste a JS snippet in your browser console, copy the output back.

The script:
- Checks if you're already logged in
- Offers the appropriate login method
- Starts the proxy servers
- Opens the dashboard

### Option 2: Manual Setup

#### Qwen Proxy (auto-login, no captcha)

```bash
cd mini-services/qwen-proxy
# Edit .env with your Qwen credentials
nano .env
# Install deps
bun install
bunx playwright install chromium
# Start
./manage.sh start
```

Qwen auto-logs in — just provide email + password in `.env`.

#### DeepSeek Proxy (requires session export)

DeepSeek uses AWS WAF captcha that can't be solved headless. You need to export your session:

```bash
cd mini-services/deepseek-proxy

# Method 1: Use setup.py (opens browser, captures session)
cd ../..
python setup.py

# Method 2: Manual export
# 1. Log into chat.deepseek.com in your browser
# 2. Open DevTools (F12) → Application tab
# 3. Copy Cookies for .deepseek.com (need: aws-waf-token, smidV2)
# 4. Copy Local Storage (need: userToken, settingsJwt, __appKit_userInfo)
# 5. Save to mini-services/deepseek-proxy/session.json
#    (see session.json.template for the format)
# 6. Start the proxy
bun install
bunx playwright install chromium
./manage.sh start
```

---

## Running It

You need **three terminals** (or use `setup.py` which handles everything):

### Terminal 1: Qwen Proxy (port 3030)
```bash
cd mini-services/qwen-proxy
./manage.sh start
```

### Terminal 2: DeepSeek Proxy (port 3032)
```bash
cd mini-services/deepseek-proxy
./manage.sh start
```

### Terminal 3: Dashboard (port 3000)
```bash
npm run dev
```

Open http://localhost:3000

---

## Using with Cline (VS Code)

1. Open Cline settings in VS Code
2. **API Provider**: `OpenAI Compatible`
3. **Base URL**: `http://localhost:3000/api/v1`
4. **API Key**: `sk-local` (any string works)
5. **Model**: see table below

### Available Models

| Provider | Model | Description | Port |
|----------|-------|-------------|------|
| Qwen | `qwen3.7-plus` | High-performance multimodal | 3030 |
| Qwen | `qwen3.8-max` | Flagship reasoning | 3030 |
| Qwen | `qwen3.7-max` | Text-only thinking | 3030 |
| Qwen | `qwen3.6-plus` | Multimodal | 3030 |
| Qwen | `qwen3.5-plus` | Multimodal | 3030 |
| Qwen | `qwen3.5-omni-plus` | Omni (262K context) | 3030 |
| DeepSeek | `deepseek-chat` | Instant mode (V3) | 3032 |
| DeepSeek | `deepseek-reasoner` | Deep thinking (R1) | 3032 |

The API automatically routes based on model name:
- `qwen*` → Qwen proxy (port 3030)
- `deepseek*` → DeepSeek proxy (port 3032)

---

## Stop Support

When you press Stop in Cline:
1. The proxy detects the disconnect within 2 seconds (heartbeat)
2. It clicks the Stop button in the Qwen/DeepSeek UI
3. Generation stops immediately
4. The next request starts instantly (no waiting)

---

## Thinking Modes

| Mode | Qwen | DeepSeek | When to use |
|------|------|----------|-------------|
| Auto | Default | — | General use |
| Thinking | `thinking: true` | `deepseek-reasoner` | Complex problems |
| Fast | `thinking: false` | `deepseek-chat` | Quick responses |

For API/Cline, pass the mode in the request body:
```json
{
  "model": "qwen3.7-plus",
  "messages": [...],
  "thinking": false,
  "search": true
}
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/chat/completions` | OpenAI-compatible chat (streaming) |
| GET | `/api/v1/models` | List all models (Qwen + DeepSeek) |
| GET | `/api/v1/chats` | List Qwen chat history |
| POST | `/api/v1/chats/new` | Start a new Qwen chat |
| GET | `/api/v1/logs` | Request history (persisted) |
| GET | `/api/v1/analytics` | Token usage stats |
| GET | `/api/v1/health` | Proxy health check |

---

## Test with curl

```bash
# Qwen (streaming)
curl -N http://localhost:3000/api/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"qwen3.7-plus","messages":[{"role":"user","content":"Hi"}],"stream":true}'

# DeepSeek (streaming)
curl -N http://localhost:3000/api/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"Hi"}],"stream":true}'
```

---

## Proxy Management

```bash
cd mini-services/qwen-proxy    # or deepseek-proxy
./manage.sh start     # Start
./manage.sh stop      # Stop
./manage.sh restart   # Restart
./manage.sh status    # Check status
```

---

## Troubleshooting

### Preview shows black screen / Z.ai logo
The dev server crashed (memory pressure from 2 Chromium instances). Restart:
```bash
pkill -f "next dev"; sleep 2; cd /path/to/project && setsid bash -c 'bun run dev' &
```

### "Proxy offline" in dashboard
```bash
./manage.sh status  # check if running
./manage.sh start   # start if down
```

### DeepSeek session expired
Re-export your cookies from the browser and update `session.json`:
```bash
python setup.py  # choose DeepSeek → Browser Login
```

### Login fails for Qwen
- Verify email/password in `.env`
- Try logging in manually at chat.qwen.ai first
- The session is saved in `.browser-data/` — delete it to force re-login:
```bash
rm -rf mini-services/qwen-proxy/.browser-data
./manage.sh restart
```

### Streaming cuts off long code
Make sure you're using the latest proxy (SSE interception, not DOM scraping):
```bash
./manage.sh restart
```

---

## File Structure

```
qwen-chat-api-local/
├── setup.py                   # Interactive setup script (run this first!)
├── package.json               # Next.js dashboard
├── src/app/
│   ├── page.tsx               # Dashboard (6 tabs)
│   └── api/v1/[...path]/route.ts  # Model routing (qwen→3030, deepseek→3032)
├── mini-services/
│   ├── qwen-proxy/            # Qwen proxy (port 3030)
│   │   ├── index.ts           # SSE stream interception + stop support
│   │   ├── manage.sh          # Start/stop/status
│   │   └── .env               # Your Qwen credentials
│   └── deepseek-proxy/        # DeepSeek proxy (port 3032)
│       ├── index.ts           # SSE stream interception + stop support
│       ├── manage.sh          # Start/stop/status
│       ├── .env               # Your credentials
│       └── session.json.template  # DeepSeek session format
└── README.md                  # This file
```

---

## Security Notes

- **Never commit `.env`** or `session.json` — they contain credentials
- `.gitignore` excludes `.env`, `.browser-data/`, `logs.json`, `session.json`
- The proxy doesn't enforce API key auth — don't expose ports to the internet
- Logs in `logs.json` contain prompt/response text — be mindful of sensitive data

---

## Support

- GitHub: https://github.com/ggcoding771/qwen-chat-api
- Live dashboard: https://qwen-chat-api.pages.dev
