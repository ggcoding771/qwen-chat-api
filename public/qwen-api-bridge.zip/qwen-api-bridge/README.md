# Qwen + DeepSeek API Bridge

Chrome extension + Python server. No Playwright, no Chromium, no npm.

## Quick Start

```bash
# 1. Install
bash install.sh

# 2. Load extension in Chrome
#    chrome://extensions → Developer mode → Load unpacked → qwen-extension/

# 3. Open tabs
#    https://chat.qwen.ai (log in)
#    https://chat.deepseek.com (log in)

# 4. Start server
python3 server.py

# 5. Open http://localhost:8000
```

## Cline Setup
- API Provider: OpenAI Compatible
- Base URL: http://localhost:8000/v1
- API Key: sk-local
- Model: qwen3.7-plus or deepseek-chat

## How it works
1. Chrome extension connects to Python server via WebSocket
2. Cline sends request to Python server
3. Python server forwards to extension
4. Extension fills the chat input + clicks send
5. Extension intercepts the SSE response
6. Streams back to Python server → Cline

## Phone support (Termux + Kiwi Browser)
1. Install Kiwi Browser (supports Chrome extensions)
2. Load the extension in Kiwi
3. Open chat.qwen.ai + chat.deepseek.com tabs
4. Run `python3 server.py` in Termux
5. Use from any device on your network
